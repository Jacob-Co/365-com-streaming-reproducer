﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExcelRtdTest
{
    internal class Constants
    {
        public const string AddinProgId = "RtdTestAddin.Connector.1";
        public const string AddinGuid = "6C9582BF-C3E8-49B6-82E8-DFD268B67D7A";
        public const string ServerProgId = "RtdTest.RtdServer";
        public const string ServerGuid = "CAD1A0A0-0B66-4BCB-8473-4B22C0E336FF";
    }
}
